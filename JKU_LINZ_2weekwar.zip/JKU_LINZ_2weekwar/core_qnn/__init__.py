name = "core_qnn"
